<?php
/*
Plugin Name: Product counter per order
Description: Adds a column to the WooCommerce orders table showing the number of products in each order.
Version: 1.0
Author: Nxvermore
Author URI: https://github.com/nxvrmore
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Add new column to orders table
add_filter('manage_edit-shop_order_columns', 'custom_shop_order_column', 20);
function custom_shop_order_column($columns) {
    $new_columns = array();
    
    foreach ($columns as $key => $column) {
        $new_columns[$key] = $column;
        if ('order_total' === $key) {
            $new_columns['order_item_count'] = 'Nº de Artículos';
        }
    }
    
    return $new_columns;
}

// Fill the column with the number of items
add_action('manage_shop_order_posts_custom_column', 'custom_shop_order_column_content');
function custom_shop_order_column_content($column) {
    global $post;
    
    if ('order_item_count' === $column) {
        $order = wc_get_order($post->ID);
        $item_count = $order->get_item_count();
        echo esc_html($item_count);
    }
}
